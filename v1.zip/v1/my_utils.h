
#ifndef EPUCKER_MY_UTILS_H
#define EPUCKER_MY_UTILS_H

void staller(int dur);

void stall_ms(long dur);

#endif //EPUCKER_MY_UTILS_H
