
#ifndef EPUCKER_LISTEN_H
#define EPUCKER_LISTEN_H

void listen(char *heard_word, int max_word_len);

#endif //EPUCKER_LISTEN_H
