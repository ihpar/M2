//
// Created by istir on 1/29/2020.
//

#ifndef EPUCKER_ROTATOR_H
#define EPUCKER_ROTATOR_H

void rotate_bot();

#endif //EPUCKER_ROTATOR_H
