#ifndef EPUCKER_TALK_H
#define EPUCKER_TALK_H

void talk(char *word, int max_word_len);

#endif //EPUCKER_TALK_H
